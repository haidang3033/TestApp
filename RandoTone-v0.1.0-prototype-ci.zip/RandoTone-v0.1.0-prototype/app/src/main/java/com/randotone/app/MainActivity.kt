package com.randotone.app

import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                RandoToneApp(applicationContext)
            }
        }
    }
}

private fun darkColorScheme() = androidx.compose.material3.darkColorScheme()

enum class PickMode(val label: String, val icon: String) {
    RANDOM("Random", "🎲"),
    SHUFFLE("Shuffle bag", "🔀"),
    NO_REPEAT("No repeat", "🚫")
}

data class SoundItem(
    val id: String,
    val uri: String,
    val name: String,
    val enabled: Boolean = true
)

data class SoundPool(
    val id: String,
    val name: String,
    val mode: PickMode = PickMode.SHUFFLE,
    val sounds: List<SoundItem> = emptyList()
)

private class RandoToneState(private val context: Context) {
    private val prefs = context.getSharedPreferences("randotone_v01", Context.MODE_PRIVATE)

    var pools by mutableStateOf(loadPools())
        private set

    var nowPlaying by mutableStateOf<String?>(null)
        private set

    var lastResult by mutableStateOf<String?>(null)
        private set

    private var player: MediaPlayer? = null
    private val lastByPool = mutableMapOf<String, String>()
    private val shuffleBags = mutableMapOf<String, MutableList<String>>()

    fun createPool(name: String) {
        val clean = name.trim().ifBlank { "New pool" }
        pools = pools + SoundPool(UUID.randomUUID().toString(), clean)
        save()
    }

    fun deletePool(poolId: String) {
        if (pools.size <= 1) return
        pools = pools.filterNot { it.id == poolId }
        shuffleBags.remove(poolId)
        lastByPool.remove(poolId)
        save()
    }

    fun setMode(poolId: String, mode: PickMode) {
        pools = pools.map { if (it.id == poolId) it.copy(mode = mode) else it }
        shuffleBags.remove(poolId)
        save()
    }

    fun addSounds(poolId: String, uris: List<Uri>) {
        if (uris.isEmpty()) return

        val additions = uris.map { uri ->
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: SecurityException) {
                // Some document providers grant access without a persistable grant.
            }

            SoundItem(
                id = uri.toString(),
                uri = uri.toString(),
                name = displayName(context, uri)
            )
        }

        pools = pools.map { pool ->
            if (pool.id != poolId) pool
            else {
                val existing = pool.sounds.map { it.uri }.toSet()
                pool.copy(sounds = pool.sounds + additions.filterNot { it.uri in existing })
            }
        }
        shuffleBags.remove(poolId)
        save()
    }

    fun setSoundEnabled(poolId: String, soundId: String, enabled: Boolean) {
        pools = pools.map { pool ->
            if (pool.id != poolId) pool
            else pool.copy(
                sounds = pool.sounds.map { sound ->
                    if (sound.id == soundId) sound.copy(enabled = enabled) else sound
                }
            )
        }
        shuffleBags.remove(poolId)
        save()
    }

    fun removeSound(poolId: String, soundId: String) {
        pools = pools.map { pool ->
            if (pool.id != poolId) pool
            else pool.copy(sounds = pool.sounds.filterNot { it.id == soundId })
        }
        shuffleBags.remove(poolId)
        save()
    }

    fun preview(sound: SoundItem) {
        play(sound)
        lastResult = "Preview: ${sound.name}"
    }

    fun roll(poolId: String) {
        val pool = pools.firstOrNull { it.id == poolId } ?: return
        val enabled = pool.sounds.filter { it.enabled }

        if (enabled.isEmpty()) {
            lastResult = "${pool.name}: no enabled sounds"
            return
        }

        val chosen = when (pool.mode) {
            PickMode.RANDOM -> enabled.random()
            PickMode.NO_REPEAT -> {
                val last = lastByPool[poolId]
                val choices = if (enabled.size > 1) enabled.filterNot { it.id == last } else enabled
                choices.random()
            }
            PickMode.SHUFFLE -> pickFromShuffleBag(pool, enabled)
        }

        lastByPool[poolId] = chosen.id
        lastResult = "${pool.mode.icon} ${pool.name} → ${chosen.name}"
        play(chosen)
    }

    private fun pickFromShuffleBag(pool: SoundPool, enabled: List<SoundItem>): SoundItem {
        val enabledIds = enabled.map { it.id }.toSet()
        var bag = shuffleBags[pool.id]

        if (bag == null || bag.isEmpty() || bag.any { it !in enabledIds }) {
            bag = enabled.map { it.id }.shuffled().toMutableList()
            val last = lastByPool[pool.id]
            if (bag.size > 1 && bag.firstOrNull() == last) {
                val swapIndex = bag.indexOfFirst { it != last }
                if (swapIndex > 0) {
                    val first = bag[0]
                    bag[0] = bag[swapIndex]
                    bag[swapIndex] = first
                }
            }
            shuffleBags[pool.id] = bag
        }

        val id = bag.removeAt(0)
        return enabled.first { it.id == id }
    }

    private fun play(sound: SoundItem) {
        player?.release()
        player = null
        nowPlaying = sound.id

        try {
            val mp = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                setDataSource(context, Uri.parse(sound.uri))
                setOnPreparedListener { it.start() }
                setOnCompletionListener {
                    it.release()
                    if (player === it) player = null
                    nowPlaying = null
                }
                setOnErrorListener { badPlayer, _, _ ->
                    badPlayer.release()
                    if (player === badPlayer) player = null
                    nowPlaying = null
                    lastResult = "Could not play ${sound.name}"
                    true
                }
                prepareAsync()
            }
            player = mp
        } catch (_: Exception) {
            nowPlaying = null
            lastResult = "Could not open ${sound.name}"
        }
    }

    fun stop() {
        player?.release()
        player = null
        nowPlaying = null
    }

    private fun save() {
        val root = JSONArray()
        pools.forEach { pool ->
            val sounds = JSONArray()
            pool.sounds.forEach { sound ->
                sounds.put(
                    JSONObject()
                        .put("id", sound.id)
                        .put("uri", sound.uri)
                        .put("name", sound.name)
                        .put("enabled", sound.enabled)
                )
            }
            root.put(
                JSONObject()
                    .put("id", pool.id)
                    .put("name", pool.name)
                    .put("mode", pool.mode.name)
                    .put("sounds", sounds)
            )
        }
        prefs.edit().putString("pools", root.toString()).apply()
    }

    private fun loadPools(): List<SoundPool> {
        val raw = prefs.getString("pools", null)
            ?: return listOf(SoundPool("default", "General notifications"))

        return try {
            val root = JSONArray(raw)
            val loaded = mutableListOf<SoundPool>()
            for (i in 0 until root.length()) {
                val p = root.getJSONObject(i)
                val soundArray = p.optJSONArray("sounds") ?: JSONArray()
                val sounds = mutableListOf<SoundItem>()
                for (j in 0 until soundArray.length()) {
                    val s = soundArray.getJSONObject(j)
                    sounds += SoundItem(
                        id = s.getString("id"),
                        uri = s.getString("uri"),
                        name = s.getString("name"),
                        enabled = s.optBoolean("enabled", true)
                    )
                }
                loaded += SoundPool(
                    id = p.getString("id"),
                    name = p.getString("name"),
                    mode = runCatching { PickMode.valueOf(p.getString("mode")) }
                        .getOrDefault(PickMode.SHUFFLE),
                    sounds = sounds
                )
            }
            loaded.ifEmpty { listOf(SoundPool("default", "General notifications")) }
        } catch (_: Exception) {
            listOf(SoundPool("default", "General notifications"))
        }
    }
}

private fun displayName(context: Context, uri: Uri): String {
    context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
        ?.use { cursor ->
            if (cursor.moveToFirst()) {
                val column = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (column >= 0) return cursor.getString(column)
            }
        }
    return uri.lastPathSegment ?: "Sound"
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun RandoToneApp(context: Context) {
    val state = remember { RandoToneState(context) }
    var importTargetPool by remember { mutableStateOf<String?>(null) }
    var showNewPoolDialog by remember { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        val target = importTargetPool
        if (target != null) state.addSounds(target, uris)
        importTargetPool = null
    }

    DisposableEffect(Unit) {
        onDispose { state.stop() }
    }

    if (showNewPoolDialog) {
        NewPoolDialog(
            onDismiss = { showNewPoolDialog = false },
            onCreate = {
                state.createPool(it)
                showNewPoolDialog = false
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("RandoTone", fontWeight = FontWeight.Bold)
                        Text("v0.1 prototype • sound roulette engine", style = MaterialTheme.typography.labelSmall)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                IntroCard()
            }

            state.lastResult?.let { result ->
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.secondaryContainer
                        )
                    ) {
                        Text(
                            result,
                            modifier = Modifier.padding(14.dp),
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }

            items(state.pools, key = { it.id }) { pool ->
                PoolCard(
                    pool = pool,
                    nowPlaying = state.nowPlaying,
                    allowDelete = state.pools.size > 1,
                    onMode = { state.setMode(pool.id, it) },
                    onAdd = {
                        importTargetPool = pool.id
                        picker.launch(arrayOf("audio/*"))
                    },
                    onRoll = { state.roll(pool.id) },
                    onPreview = { state.preview(it) },
                    onToggle = { soundId, enabled ->
                        state.setSoundEnabled(pool.id, soundId, enabled)
                    },
                    onRemove = { state.removeSound(pool.id, it) },
                    onDeletePool = { state.deletePool(pool.id) }
                )
            }

            item {
                OutlinedButton(
                    onClick = { showNewPoolDialog = true },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("＋ Create another pool")
                }
            }

            item {
                RoadmapCard()
            }
        }
    }
}

@Composable
private fun IntroCard() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer
        )
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text("🔔 Tiny notification jukebox, stage one", fontWeight = FontWeight.Bold)
            Text(
                "Create sound pools, import audio, choose a selection rule, then hit ROLL & PLAY. " +
                    "No account, no network, no broad storage permission."
            )
        }
    }
}

@Composable
private fun PoolCard(
    pool: SoundPool,
    nowPlaying: String?,
    allowDelete: Boolean,
    onMode: (PickMode) -> Unit,
    onAdd: () -> Unit,
    onRoll: () -> Unit,
    onPreview: (SoundItem) -> Unit,
    onToggle: (String, Boolean) -> Unit,
    onRemove: (String) -> Unit,
    onDeletePool: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(pool.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text(
                        "${pool.sounds.count { it.enabled }} enabled / ${pool.sounds.size} total",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                if (allowDelete) {
                    TextButton(onClick = onDeletePool) { Text("Delete") }
                }
            }

            Text("Selection mode", style = MaterialTheme.typography.labelLarge)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                PickMode.entries.forEach { mode ->
                    FilterChip(
                        selected = pool.mode == mode,
                        onClick = { onMode(mode) },
                        label = { Text("${mode.icon} ${mode.label}") }
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(onClick = onAdd, modifier = Modifier.weight(1f)) {
                    Text("＋ Add sounds")
                }
                Button(
                    onClick = onRoll,
                    enabled = pool.sounds.any { it.enabled },
                    modifier = Modifier.weight(1f)
                ) {
                    Text("🎲 ROLL & PLAY")
                }
            }

            if (pool.sounds.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 20.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No sounds yet. Feed the machine some audio.")
                }
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    pool.sounds.forEach { sound ->
                        SoundRow(
                            sound = sound,
                            playing = nowPlaying == sound.id,
                            onPreview = { onPreview(sound) },
                            onToggle = { onToggle(sound.id, it) },
                            onRemove = { onRemove(sound.id) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SoundRow(
    sound: SoundItem,
    playing: Boolean,
    onPreview: () -> Unit,
    onToggle: (Boolean) -> Unit,
    onRemove: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Checkbox(checked = sound.enabled, onCheckedChange = onToggle)
        Column(modifier = Modifier.weight(1f)) {
            Text(
                sound.name,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                fontWeight = if (playing) FontWeight.Bold else FontWeight.Normal
            )
            if (playing) Text("playing…", style = MaterialTheme.typography.labelSmall)
        }
        TextButton(onClick = onPreview) { Text(if (playing) "🔊" else "▶") }
        TextButton(onClick = onRemove) { Text("✕") }
    }
}

@Composable
private fun RoadmapCard() {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            Text("Next sockets", fontWeight = FontWeight.Bold)
            Text("v0.2  • Notification listener + per-app pool rules")
            Text("v0.3  • Ringtone rotation")
            Text("v0.4  • Alarm clock + random alarm pools")
            Spacer(Modifier.height(2.dp))
            Text(
                "This prototype intentionally keeps those switches unwired until the pool engine survives real-phone testing.",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

@Composable
private fun NewPoolDialog(onDismiss: () -> Unit, onCreate: (String) -> Unit) {
    var name by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Create sound pool") },
        text = {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Pool name") },
                singleLine = true
            )
        },
        confirmButton = {
            TextButton(onClick = { onCreate(name) }) { Text("Create") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
