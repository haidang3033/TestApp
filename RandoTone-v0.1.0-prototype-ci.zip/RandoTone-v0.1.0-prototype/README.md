# RandoTone v0.1.0 prototype

A tiny offline Android prototype for sound-pool roulette.

## What works now

- Create multiple sound pools.
- Pick multiple audio files using Android's system file picker.
- Persist file access and pool configuration across restarts.
- Enable/disable or remove individual sounds.
- Preview any sound.
- `Random` mode.
- `Shuffle bag` mode: every enabled sound is used once before the bag refills, while avoiding an immediate boundary repeat when possible.
- `No repeat` mode: random selection excluding the immediately previous sound when there is more than one choice.
- One-tap **ROLL & PLAY** test for each pool.
- Fully offline and no broad storage permission.

## Deliberately not in v0.1

This build does **not** intercept notifications, rotate the system ringtone, or schedule alarms yet. The point of v0.1 is to test the library / persistence / selection / playback foundation first.

Planned sequence:

- v0.2: NotificationListenerService + per-app sound pool rules.
- v0.3: system ringtone rotation.
- v0.4: alarm scheduler and alarm screen.

## Build

Recommended current toolchain for this snapshot:

- Android Studio with JDK 17.
- Android SDK Platform 37 installed.
- Gradle wrapper 9.5.0.
- Android Gradle Plugin 9.3.0.

This archive cannot carry the binary Gradle wrapper JAR from the build environment. On Windows, run **`bootstrap-wrapper.bat` once**; it fetches the official Gradle 9.5.0 wrapper JAR from the Gradle GitHub repository. Then open the project root in Android Studio, let Gradle sync, and run the `app` configuration on a device or emulator.

### If Android Studio says SDK 37 is missing

Open **Tools → SDK Manager → SDK Platforms**, install Android 17 / API 37, then sync again.

## Phone test recipe

1. Launch RandoTone.
2. In **General notifications**, tap **Add sounds**.
3. Select at least 3 short audio files.
4. Preview each one to verify URI access/playback.
5. Pick **Shuffle bag**.
6. Tap **ROLL & PLAY** repeatedly. Each enabled sound should occur once before a refill.
7. Force-close the app and reopen it. The pool and files should still be present and playable.
8. Try **No repeat** and verify the same sound never occurs twice consecutively when at least two sounds are enabled.
9. Disable a sound and verify it is no longer selected.
10. Create another pool and verify its selection history is independent.

## Known prototype limitations

- Pool names cannot be renamed yet.
- No drag sorting or weighted probabilities yet.
- Playback is intentionally one sound at a time.
- A document provider that refuses persistable URI grants may make a picked file unavailable after a reboot; normal Android file providers should work.
- No notification/call/alarm permissions are requested in v0.1.

## Package

`com.randotone.app`
