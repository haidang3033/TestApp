@ECHO OFF
PowerShell -NoProfile -ExecutionPolicy Bypass -File "%~dp0bootstrap-wrapper.ps1"
PAUSE
