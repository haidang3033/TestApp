# RandoTone v0.2.0 prototype

RandoTone v0.2 adds real Android notification roulette on top of the v0.1 sound-pool engine.

## What v0.2 contains

- Persistent sound pools from v0.1
- Random, No Repeat, and Shuffle Bag selection
- Android `NotificationListenerService`
- Master notification-roulette switch
- Default notification pool
- Per-app rules:
  - use default pool
  - use a specific pool
  - exclude app
- Observed-app list populated from real notifications
- Shortcut to each app's Android notification settings
- Local recent-event history (up to 50 events)
- Do Not Disturb respect through notification ranking
- Duplicate/update suppression
- Group-summary, ongoing, call, and alarm notification filtering
- 1.5 second listener connection grace window
- No notification message text is written to history
- No network permission and no broad storage permission

## Important Android limitation

RandoTone receives a notification after Android has posted it. The source app's own notification-channel sound may therefore already have played.

For apps you want RandoTone to handle, set the original Android notification sound/channel sound to **Silent** or **None**. Each observed-app card has an **Android sound settings** button to get there quickly.

RandoTone does not cancel or rewrite another app's notification in v0.2.

## One-time install note from v0.1

The old v0.1 GitHub Actions build used the runner's temporary debug signing key. That key is not recoverable from the APK.

v0.2 introduces a dedicated **prototype-only signing key** stored in this project so v0.2 and later prototype builds use the same certificate.

Because the v0.1 certificate is different, Android will normally refuse to install v0.2 over v0.1. If that happens:

1. Uninstall RandoTone v0.1.
2. Install v0.2.
3. Re-import the test sounds.

This should be the last prototype-signature reset. Do not use the included prototype key for a public production release.

Prototype certificate SHA-256:

`05:21:70:23:14:52:37:D9:59:2F:E0:B0:E5:38:CC:38:35:AF:80:AC:1C:7E:19:D5:A0:B9:65:A3:96:40:DC:FD`

## Phone-only GitHub Actions build

Use the supplied outer workflow file:

`build-randotone-v0.2-from-zip.yml`

and upload this project ZIP to the same repo as:

`RandoTone-v0.2.0-prototype-ci.zip`

The workflow:

1. installs JDK 17 and Android SDK platform 37,
2. installs Gradle 9.5.0,
3. verifies the prototype signing key,
4. runs `:app:assembleDebug`,
5. verifies the APK signature with `apksigner`,
6. uploads `RandoTone-v0.2.0-prototype.apk`.

If the build fails, the workflow prints Kotlin/compiler errors separately near the end.

## Recommended v0.2 test sequence

### A. Basic regression

1. Install and launch v0.2.
2. Create/import a pool with at least 3 sounds.
3. Test Preview, Random, No Repeat, and Shuffle Bag.
4. Close and reopen the app and confirm the pool persists.

### B. Notification listener

1. Tap **Grant notification access**.
2. Enable RandoTone in Android's notification-access screen.
3. Return to RandoTone and confirm `Notification access: granted`.
4. Enable **Master roulette**.
5. Set the default pool.
6. Have another app send a normal notification.
7. Confirm that app appears under **Per-app rules** and RandoTone plays one pool sound.

### C. Prevent double sounds

1. In the observed app card, tap **Android sound settings**.
2. Set that app/channel's original sound to Silent/None.
3. Trigger another notification.
4. Confirm only the RandoTone sound is heard.

### D. Per-app rule

1. Create a second pool.
2. Configure an observed app to use that specific pool.
3. Trigger another notification from that app.
4. Confirm the chosen sound comes from the assigned pool.

### E. Exclusion

1. Configure an app as **Excluded**.
2. Trigger a notification from it.
3. Confirm RandoTone stays silent and history says `Excluded by app rule`.

### F. Do Not Disturb

1. Turn on Android Do Not Disturb so the test notification is blocked from interrupting.
2. Trigger a notification.
3. Confirm RandoTone does not play and history reports that DND blocked it.

### G. Duplicate resistance

Trigger a notification from an app that updates its notification card after posting. One logical alert should not cause a rapid series of RandoTone sounds merely because the notification content was refreshed.

## Architecture

- `Models.kt` - data models
- `SelectionEngine.kt` - pure selection logic
- `RandoToneRepository.kt` - SharedPreferences persistence and selection state
- `RandoToneNotificationListener.kt` - Android notification listener and background playback
- `RandoToneState.kt` - UI-facing state and preview playback
- `MainActivity.kt` - Compose UI

The selection engine is intentionally pure Kotlin so it can be tested independently from Android.

## Validation already performed before packaging

- Random/No Repeat/Shuffle Bag pure-Kotlin tests passed.
- Shuffle Bag was checked across repeated full cycles for one-use-per-cycle behavior and no immediate cycle-boundary repeat.
- Android XML files parse successfully.
- GitHub Actions YAML parses successfully.
- Kotlin files passed a parser-level syntax scan.
- Prototype keystore was generated and verified with `keytool`.

A full Android compile still requires the Android SDK, which is not available in the local generation environment, so the supplied GitHub Actions workflow remains the authoritative compile check.
