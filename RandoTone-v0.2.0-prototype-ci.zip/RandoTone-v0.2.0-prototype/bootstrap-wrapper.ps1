$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$wrapperDir = Join-Path $root "gradle\wrapper"
$jar = Join-Path $wrapperDir "gradle-wrapper.jar"
$url = "https://github.com/gradle/gradle/raw/refs/tags/v9.5.0/gradle/wrapper/gradle-wrapper.jar"

New-Item -ItemType Directory -Force -Path $wrapperDir | Out-Null
Write-Host "Fetching the official Gradle 9.5.0 wrapper JAR..."
Invoke-WebRequest -Uri $url -OutFile $jar
Write-Host "Wrapper ready: $jar"
Write-Host "You can now open the project in Android Studio or run .\gradlew.bat tasks"
