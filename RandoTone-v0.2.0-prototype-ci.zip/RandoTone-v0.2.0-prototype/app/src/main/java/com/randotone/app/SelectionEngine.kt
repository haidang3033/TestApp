package com.randotone.app

import kotlin.random.Random

object SelectionEngine {
    fun choose(
        mode: PickMode,
        enabledIds: List<String>,
        state: SelectionState,
        random: Random = Random.Default
    ): SelectionDecision? {
        val candidates = enabledIds.distinct()
        if (candidates.isEmpty()) return null

        return when (mode) {
            PickMode.RANDOM -> {
                val chosen = candidates.random(random)
                SelectionDecision(chosen, SelectionState(lastId = chosen))
            }

            PickMode.NO_REPEAT -> {
                val choices = if (candidates.size > 1) {
                    candidates.filterNot { it == state.lastId }
                } else {
                    candidates
                }
                val chosen = choices.random(random)
                SelectionDecision(chosen, SelectionState(lastId = chosen))
            }

            PickMode.SHUFFLE -> {
                val allowed = candidates.toSet()
                val remaining = state.bag
                    .filter { it in allowed }
                    .distinct()
                    .toMutableList()

                if (remaining.isEmpty()) {
                    remaining += candidates.shuffled(random)
                    if (remaining.size > 1 && remaining.first() == state.lastId) {
                        val swapIndex = remaining.indexOfFirst { it != state.lastId }
                        if (swapIndex > 0) {
                            val first = remaining[0]
                            remaining[0] = remaining[swapIndex]
                            remaining[swapIndex] = first
                        }
                    }
                }

                val chosen = remaining.removeAt(0)
                SelectionDecision(
                    soundId = chosen,
                    nextState = SelectionState(
                        lastId = chosen,
                        bag = remaining.toList()
                    )
                )
            }
        }
    }
}
