package com.randotone.app

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.provider.Settings
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

class RandoToneState(private val context: Context) {
    private val repository = RandoToneRepository(context)

    var pools by mutableStateOf(repository.loadPools())
        private set
    var notificationEnabled by mutableStateOf(repository.isNotificationEnabled())
        private set
    var defaultPoolId by mutableStateOf(repository.getDefaultPoolId(pools))
        private set
    var observedApps by mutableStateOf(repository.loadObservedApps())
        private set
    var history by mutableStateOf(repository.loadHistory())
        private set
    var nowPlaying by mutableStateOf<String?>(null)
        private set
    var lastResult by mutableStateOf<String?>(null)
        private set

    private var player: MediaPlayer? = null

    private val preferenceListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        when (key) {
            RandoToneRepository.KEY_POOLS -> {
                pools = repository.loadPools()
                defaultPoolId = repository.getDefaultPoolId(pools)
            }
            RandoToneRepository.KEY_NOTIFICATION_ENABLED -> {
                notificationEnabled = repository.isNotificationEnabled()
            }
            RandoToneRepository.KEY_DEFAULT_POOL -> {
                defaultPoolId = repository.getDefaultPoolId(pools)
            }
            RandoToneRepository.KEY_OBSERVED_APPS -> {
                observedApps = repository.loadObservedApps()
            }
            RandoToneRepository.KEY_HISTORY -> {
                history = repository.loadHistory()
            }
        }
    }

    init {
        repository.registerListener(preferenceListener)
    }

    fun createPool(name: String) {
        repository.createPool(name)
        refreshPools()
    }

    fun deletePool(poolId: String) {
        repository.deletePool(poolId)
        refreshPools()
    }

    fun setMode(poolId: String, mode: PickMode) {
        repository.setMode(poolId, mode)
        refreshPools()
    }

    fun addSounds(poolId: String, uris: List<Uri>) {
        repository.addSounds(poolId, uris)
        refreshPools()
    }

    fun setSoundEnabled(poolId: String, soundId: String, enabled: Boolean) {
        repository.setSoundEnabled(poolId, soundId, enabled)
        refreshPools()
    }

    fun removeSound(poolId: String, soundId: String) {
        repository.removeSound(poolId, soundId)
        refreshPools()
    }

    fun preview(sound: SoundItem) {
        play(sound)
        lastResult = "Preview: ${sound.name}"
    }

    fun roll(poolId: String) {
        val selected = repository.chooseSound(poolId)
        if (selected == null) {
            val pool = pools.firstOrNull { it.id == poolId }
            lastResult = "${pool?.name ?: "Pool"}: no enabled sounds"
            return
        }
        val (pool, sound) = selected
        lastResult = "${pool.mode.icon} ${pool.name} → ${sound.name}"
        play(sound)
    }

    fun setNotificationEnabled(enabled: Boolean) {
        repository.setNotificationEnabled(enabled)
        notificationEnabled = enabled
    }

    fun setDefaultPool(poolId: String) {
        repository.setDefaultPoolId(poolId)
        defaultPoolId = repository.getDefaultPoolId(pools)
    }

    fun getRule(packageName: String): AppRule = repository.getRule(packageName)

    fun setRuleDefault(packageName: String) {
        repository.setRuleDefault(packageName)
    }

    fun setRuleExcluded(packageName: String) {
        repository.setRuleExcluded(packageName)
    }

    fun setRulePool(packageName: String, poolId: String) {
        repository.setRulePool(packageName, poolId)
    }

    fun ruleDescription(packageName: String): String {
        val rule = repository.getRule(packageName)
        return when (rule.kind) {
            RuleKind.DEFAULT -> "Default • ${poolName(defaultPoolId)}"
            RuleKind.EXCLUDED -> "Excluded"
            RuleKind.POOL -> poolName(rule.poolId)
        }
    }

    fun clearHistory() {
        repository.clearHistory()
        history = emptyList()
    }

    fun close() {
        repository.unregisterListener(preferenceListener)
        stop()
    }

    private fun poolName(poolId: String?): String {
        return pools.firstOrNull { it.id == poolId }?.name ?: "Unknown pool"
    }

    private fun refreshPools() {
        pools = repository.loadPools()
        defaultPoolId = repository.getDefaultPoolId(pools)
    }

    private fun play(sound: SoundItem) {
        player?.release()
        player = null
        nowPlaying = sound.id

        try {
            val mp = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                setDataSource(context, Uri.parse(sound.uri))
                setOnPreparedListener { prepared ->
                    if (player === prepared) prepared.start() else prepared.release()
                }
                setOnCompletionListener { completed ->
                    completed.release()
                    if (player === completed) player = null
                    nowPlaying = null
                }
                setOnErrorListener { badPlayer, _, _ ->
                    badPlayer.release()
                    if (player === badPlayer) player = null
                    nowPlaying = null
                    lastResult = "Could not play ${sound.name}"
                    true
                }
                prepareAsync()
            }
            player = mp
        } catch (_: Exception) {
            nowPlaying = null
            lastResult = "Could not open ${sound.name}"
        }
    }

    private fun stop() {
        player?.release()
        player = null
        nowPlaying = null
    }
}

fun openNotificationListenerSettings(context: Context) {
    val intent = Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    runCatching { context.startActivity(intent) }
        .recoverCatching {
            context.startActivity(
                Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }
}

fun openAppNotificationSettings(context: Context, packageName: String) {
    val intent = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
        .putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    runCatching { context.startActivity(intent) }
}
