package com.randotone.app

enum class PickMode(val label: String, val icon: String) {
    RANDOM("Random", "🎲"),
    SHUFFLE("Shuffle bag", "🔀"),
    NO_REPEAT("No repeat", "🚫")
}

data class SoundItem(
    val id: String,
    val uri: String,
    val name: String,
    val enabled: Boolean = true
)

data class SoundPool(
    val id: String,
    val name: String,
    val mode: PickMode = PickMode.SHUFFLE,
    val sounds: List<SoundItem> = emptyList()
)

data class SelectionState(
    val lastId: String? = null,
    val bag: List<String> = emptyList()
)

data class SelectionDecision(
    val soundId: String,
    val nextState: SelectionState
)

data class ObservedApp(
    val packageName: String,
    val label: String,
    val lastSeen: Long
)

enum class RuleKind {
    DEFAULT,
    POOL,
    EXCLUDED
}

data class AppRule(
    val kind: RuleKind,
    val poolId: String? = null
)

enum class HistoryOutcome(val label: String) {
    PLAYED("Played"),
    EXCLUDED("Excluded"),
    DND("Skipped by Do Not Disturb"),
    NO_POOL("No valid pool"),
    NO_SOUND("No enabled sound"),
    PLAYBACK_ERROR("Playback error")
}

data class HistoryEvent(
    val id: String,
    val timestamp: Long,
    val packageName: String,
    val appLabel: String,
    val outcome: HistoryOutcome,
    val poolName: String? = null,
    val soundName: String? = null
)
