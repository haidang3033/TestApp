package com.randotone.app

import android.app.Notification
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.SystemClock
import android.service.notification.NotificationListenerService
import android.service.notification.NotificationListenerService.Ranking
import android.service.notification.NotificationListenerService.RankingMap
import android.service.notification.StatusBarNotification

class RandoToneNotificationListener : NotificationListenerService() {
    private lateinit var repository: RandoToneRepository
    private var player: MediaPlayer? = null
    private val lastSignatures = LinkedHashMap<String, String>()
    private var connectedAtElapsed = 0L

    override fun onCreate() {
        super.onCreate()
        repository = RandoToneRepository(applicationContext)
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        connectedAtElapsed = SystemClock.elapsedRealtime()
    }

    override fun onNotificationPosted(
        sbn: StatusBarNotification,
        rankingMap: RankingMap
    ) {
        if (shouldHardIgnore(sbn)) return

        val appLabel = resolveAppLabel(sbn.packageName, sbn.notification)
        repository.recordObservedApp(sbn.packageName, appLabel, sbn.postTime)

        if (!repository.isNotificationEnabled()) return
        if (SystemClock.elapsedRealtime() - connectedAtElapsed < CONNECTION_GRACE_MS) return
        if (isDuplicateOrNonAlertingUpdate(sbn)) return

        val ranking = Ranking()
        if (rankingMap.getRanking(sbn.key, ranking) && !ranking.matchesInterruptionFilter()) {
            repository.addHistory(
                packageName = sbn.packageName,
                appLabel = appLabel,
                outcome = HistoryOutcome.DND
            )
            return
        }

        val rule = repository.getRule(sbn.packageName)
        if (rule.kind == RuleKind.EXCLUDED) {
            repository.addHistory(
                packageName = sbn.packageName,
                appLabel = appLabel,
                outcome = HistoryOutcome.EXCLUDED
            )
            return
        }

        val pool = repository.resolvePoolFor(sbn.packageName)
        if (pool == null) {
            repository.addHistory(
                packageName = sbn.packageName,
                appLabel = appLabel,
                outcome = HistoryOutcome.NO_POOL
            )
            return
        }

        val selected = repository.chooseSound(pool.id)
        if (selected == null) {
            repository.addHistory(
                packageName = sbn.packageName,
                appLabel = appLabel,
                outcome = HistoryOutcome.NO_SOUND,
                poolName = pool.name
            )
            return
        }

        val (_, sound) = selected
        playNotificationSound(
            packageName = sbn.packageName,
            appLabel = appLabel,
            pool = pool,
            sound = sound
        )
    }

    override fun onDestroy() {
        player?.release()
        player = null
        super.onDestroy()
    }

    private fun shouldHardIgnore(sbn: StatusBarNotification): Boolean {
        if (sbn.packageName == packageName) return true

        val notification = sbn.notification
        if (notification.flags and Notification.FLAG_GROUP_SUMMARY != 0) return true
        if (notification.flags and Notification.FLAG_ONGOING_EVENT != 0) return true

        return notification.category == Notification.CATEGORY_CALL ||
            notification.category == Notification.CATEGORY_ALARM
    }

    private fun isDuplicateOrNonAlertingUpdate(sbn: StatusBarNotification): Boolean {
        val key = sbn.key
        val notification = sbn.notification
        val alreadySeen = lastSignatures.containsKey(key)

        if (alreadySeen && notification.flags and Notification.FLAG_ONLY_ALERT_ONCE != 0) {
            return true
        }

        val extras = notification.extras
        val signature = listOf(
            sbn.id.toString(),
            sbn.tag.orEmpty(),
            notification.`when`.toString(),
            notification.number.toString(),
            extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty(),
            extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty(),
            extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString().orEmpty()
        ).joinToString("\u001F")

        if (lastSignatures[key] == signature) return true

        lastSignatures[key] = signature
        while (lastSignatures.size > MAX_SIGNATURES) {
            val oldest = lastSignatures.entries.firstOrNull()?.key ?: break
            lastSignatures.remove(oldest)
        }
        return false
    }

    private fun resolveAppLabel(sourcePackage: String, notification: Notification): String {
        val packageLabel = runCatching {
            @Suppress("DEPRECATION")
            val info = packageManager.getApplicationInfo(sourcePackage, 0)
            packageManager.getApplicationLabel(info).toString()
        }.getOrNull()

        if (!packageLabel.isNullOrBlank()) return packageLabel

        val substitute = notification.extras
            .getCharSequence(Notification.EXTRA_SUBSTITUTE_APP_NAME)
            ?.toString()
            ?.trim()
        return substitute?.takeIf { it.isNotBlank() } ?: sourcePackage
    }

    private fun playNotificationSound(
        packageName: String,
        appLabel: String,
        pool: SoundPool,
        sound: SoundItem
    ) {
        player?.release()
        player = null
        var started = false

        try {
            val mp = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                setDataSource(applicationContext, Uri.parse(sound.uri))
                setOnPreparedListener {
                    if (player !== it) {
                        it.release()
                        return@setOnPreparedListener
                    }
                    started = true
                    repository.addHistory(
                        packageName = packageName,
                        appLabel = appLabel,
                        outcome = HistoryOutcome.PLAYED,
                        poolName = pool.name,
                        soundName = sound.name
                    )
                    it.start()
                }
                setOnCompletionListener {
                    it.release()
                    if (player === it) player = null
                }
                setOnErrorListener { badPlayer, _, _ ->
                    badPlayer.release()
                    if (player === badPlayer) player = null
                    if (!started) {
                        repository.addHistory(
                            packageName = packageName,
                            appLabel = appLabel,
                            outcome = HistoryOutcome.PLAYBACK_ERROR,
                            poolName = pool.name,
                            soundName = sound.name
                        )
                    }
                    true
                }
                prepareAsync()
            }
            player = mp
        } catch (_: Exception) {
            player = null
            repository.addHistory(
                packageName = packageName,
                appLabel = appLabel,
                outcome = HistoryOutcome.PLAYBACK_ERROR,
                poolName = pool.name,
                soundName = sound.name
            )
        }
    }

    companion object {
        private const val MAX_SIGNATURES = 200
        private const val CONNECTION_GRACE_MS = 1500L
    }
}
