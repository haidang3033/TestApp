package com.randotone.app

import android.app.NotificationManager
import android.content.ComponentName
import android.content.Context
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import java.text.DateFormat
import java.util.Date

class MainActivity : ComponentActivity() {
    private var notificationAccessGranted by mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        notificationAccessGranted = hasNotificationListenerAccess(this)
        setContent {
            MaterialTheme(colorScheme = androidx.compose.material3.darkColorScheme()) {
                RandoToneApp(
                    context = applicationContext,
                    notificationAccessGranted = notificationAccessGranted
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        notificationAccessGranted = hasNotificationListenerAccess(this)
    }
}

fun hasNotificationListenerAccess(context: Context): Boolean {
    val component = ComponentName(context, RandoToneNotificationListener::class.java)
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
        val manager = context.getSystemService(NotificationManager::class.java)
        return manager?.isNotificationListenerAccessGranted(component) == true
    }

    val enabled = Settings.Secure.getString(
        context.contentResolver,
        "enabled_notification_listeners"
    ) ?: return false
    return enabled.split(':').any {
        ComponentName.unflattenFromString(it) == component
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun RandoToneApp(
    context: Context,
    notificationAccessGranted: Boolean
) {
    val state = remember { RandoToneState(context) }
    var importTargetPool by remember { mutableStateOf<String?>(null) }
    var showNewPoolDialog by remember { mutableStateOf(false) }
    var showDefaultPoolDialog by remember { mutableStateOf(false) }
    var editingApp by remember { mutableStateOf<ObservedApp?>(null) }

    val picker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        importTargetPool?.let { state.addSounds(it, uris) }
        importTargetPool = null
    }

    DisposableEffect(Unit) {
        onDispose { state.close() }
    }

    if (showNewPoolDialog) {
        NewPoolDialog(
            onDismiss = { showNewPoolDialog = false },
            onCreate = {
                state.createPool(it)
                showNewPoolDialog = false
            }
        )
    }

    if (showDefaultPoolDialog) {
        PoolChoiceDialog(
            title = "Default notification pool",
            pools = state.pools,
            selectedPoolId = state.defaultPoolId,
            onDismiss = { showDefaultPoolDialog = false },
            onChoose = {
                state.setDefaultPool(it)
                showDefaultPoolDialog = false
            }
        )
    }

    editingApp?.let { app ->
        AppRuleDialog(
            app = app,
            pools = state.pools,
            currentRule = state.getRule(app.packageName),
            onDismiss = { editingApp = null },
            onDefault = {
                state.setRuleDefault(app.packageName)
                editingApp = null
            },
            onExclude = {
                state.setRuleExcluded(app.packageName)
                editingApp = null
            },
            onPool = {
                state.setRulePool(app.packageName, it)
                editingApp = null
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("RandoTone", fontWeight = FontWeight.Bold)
                        Text(
                            "v0.2 prototype • notification roulette",
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                NotificationControlCard(
                    accessGranted = notificationAccessGranted,
                    enabled = state.notificationEnabled,
                    defaultPoolName = state.pools
                        .firstOrNull { it.id == state.defaultPoolId }
                        ?.name
                        ?: "Unknown pool",
                    canTest = state.pools
                        .firstOrNull { it.id == state.defaultPoolId }
                        ?.sounds
                        ?.any { it.enabled }
                        == true,
                    onOpenAccess = { openNotificationListenerSettings(context) },
                    onEnabled = { state.setNotificationEnabled(it) },
                    onChooseDefault = { showDefaultPoolDialog = true },
                    onTest = { state.roll(state.defaultPoolId) }
                )
            }

            state.lastResult?.let { result ->
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.secondaryContainer
                        )
                    ) {
                        Text(
                            result,
                            modifier = Modifier.padding(14.dp),
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }

            item {
                AppRulesCardHeader(state.observedApps.size)
            }

            if (state.observedApps.isEmpty()) {
                item {
                    EmptyObservedAppsCard(notificationAccessGranted)
                }
            } else {
                items(state.observedApps.take(30), key = { it.packageName }) { app ->
                    ObservedAppCard(
                        app = app,
                        ruleDescription = state.ruleDescription(app.packageName),
                        onConfigure = { editingApp = app },
                        onAndroidSettings = {
                            openAppNotificationSettings(context, app.packageName)
                        }
                    )
                }
            }

            item {
                HistoryCard(
                    history = state.history,
                    onClear = { state.clearHistory() }
                )
            }

            item {
                Text(
                    "Sound pools",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
            }

            items(state.pools, key = { it.id }) { pool ->
                PoolCard(
                    pool = pool,
                    nowPlaying = state.nowPlaying,
                    allowDelete = state.pools.size > 1,
                    onMode = { state.setMode(pool.id, it) },
                    onAdd = {
                        importTargetPool = pool.id
                        picker.launch(arrayOf("audio/*"))
                    },
                    onRoll = { state.roll(pool.id) },
                    onPreview = { state.preview(it) },
                    onToggle = { soundId, enabled ->
                        state.setSoundEnabled(pool.id, soundId, enabled)
                    },
                    onRemove = { state.removeSound(pool.id, it) },
                    onDeletePool = { state.deletePool(pool.id) }
                )
            }

            item {
                OutlinedButton(
                    onClick = { showNewPoolDialog = true },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("＋ Create another pool")
                }
            }

            item {
                RoadmapCard()
            }
        }
    }
}

@Composable
private fun NotificationControlCard(
    accessGranted: Boolean,
    enabled: Boolean,
    defaultPoolName: String,
    canTest: Boolean,
    onOpenAccess: () -> Unit,
    onEnabled: (Boolean) -> Unit,
    onChooseDefault: () -> Unit,
    onTest: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer
        )
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("🔔 Notification Roulette", fontWeight = FontWeight.Bold)
            Text(
                if (accessGranted) "Notification access: granted ✓"
                else "Notification access: required"
            )
            Button(onClick = onOpenAccess, modifier = Modifier.fillMaxWidth()) {
                Text(if (accessGranted) "Notification access settings" else "Grant notification access")
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Master roulette", fontWeight = FontWeight.SemiBold)
                    Text(
                        if (accessGranted) "Play RandoTone sounds for eligible notifications"
                        else "Grant access first",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                Switch(
                    checked = enabled,
                    onCheckedChange = onEnabled,
                    enabled = accessGranted
                )
            }

            Text("Default pool: $defaultPoolName")
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(onClick = onChooseDefault, modifier = Modifier.weight(1f)) {
                    Text("Change default")
                }
                OutlinedButton(
                    onClick = onTest,
                    enabled = canTest,
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Test pool")
                }
            }

            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.errorContainer
                )
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text("Important: silence the original app sound", fontWeight = FontWeight.Bold)
                    Text(
                        "Android may play an app's own channel sound before RandoTone receives the posted notification. " +
                            "Set that app/channel sound to Silent or None to avoid hearing both. " +
                            "Use each app card's Android sound settings button below."
                    )
                }
            }

            Text(
                "RandoTone stores only app/package, time, result and chosen sound in its local history. " +
                    "It does not save notification message text.",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

@Composable
private fun AppRulesCardHeader(count: Int) {
    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Text("Per-app rules", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Text(
            "$count observed app${if (count == 1) "" else "s"} • apps appear after they post a normal notification",
            style = MaterialTheme.typography.bodySmall
        )
    }
}

@Composable
private fun EmptyObservedAppsCard(accessGranted: Boolean) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Text(
            if (accessGranted) {
                "No apps observed yet. Leave RandoTone enabled and wait for another app to send a normal notification."
            } else {
                "Grant notification access first. Apps will appear here as RandoTone observes their notifications."
            },
            modifier = Modifier.padding(16.dp)
        )
    }
}

@Composable
private fun ObservedAppCard(
    app: ObservedApp,
    ruleDescription: String,
    onConfigure: () -> Unit,
    onAndroidSettings: () -> Unit
) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(app.label, fontWeight = FontWeight.Bold)
            Text(app.packageName, style = MaterialTheme.typography.bodySmall)
            Text("Rule: $ruleDescription")
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(onClick = onConfigure, modifier = Modifier.weight(1f)) {
                    Text("Configure rule")
                }
                OutlinedButton(onClick = onAndroidSettings, modifier = Modifier.weight(1f)) {
                    Text("Android sound settings")
                }
            }
        }
    }
}

@Composable
private fun HistoryCard(
    history: List<HistoryEvent>,
    onClear: () -> Unit
) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "Recent notification events",
                    modifier = Modifier.weight(1f),
                    fontWeight = FontWeight.Bold
                )
                if (history.isNotEmpty()) {
                    TextButton(onClick = onClear) { Text("Clear") }
                }
            }

            if (history.isEmpty()) {
                Text("Nothing yet. The roulette wheel is suspiciously quiet.")
            } else {
                history.take(12).forEach { event ->
                    val time = DateFormat.getTimeInstance(DateFormat.SHORT).format(Date(event.timestamp))
                    val detail = when (event.outcome) {
                        HistoryOutcome.PLAYED -> "${event.poolName ?: "Pool"} → ${event.soundName ?: "Sound"}"
                        HistoryOutcome.EXCLUDED -> "Excluded by app rule"
                        HistoryOutcome.DND -> "Do Not Disturb blocked the alert"
                        HistoryOutcome.NO_POOL -> "No valid sound pool"
                        HistoryOutcome.NO_SOUND -> "Pool has no enabled sounds"
                        HistoryOutcome.PLAYBACK_ERROR -> "Could not play ${event.soundName ?: "selected sound"}"
                    }
                    Column {
                        Text("$time • ${event.appLabel}", fontWeight = FontWeight.SemiBold)
                        Text(detail, style = MaterialTheme.typography.bodySmall)
                    }
                }
                if (history.size > 12) {
                    Text(
                        "${history.size - 12} older events kept in local history",
                        style = MaterialTheme.typography.labelSmall
                    )
                }
            }
        }
    }
}

@Composable
private fun PoolCard(
    pool: SoundPool,
    nowPlaying: String?,
    allowDelete: Boolean,
    onMode: (PickMode) -> Unit,
    onAdd: () -> Unit,
    onRoll: () -> Unit,
    onPreview: (SoundItem) -> Unit,
    onToggle: (String, Boolean) -> Unit,
    onRemove: (String) -> Unit,
    onDeletePool: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(pool.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text(
                        "${pool.sounds.count { it.enabled }} enabled / ${pool.sounds.size} total",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                if (allowDelete) {
                    TextButton(onClick = onDeletePool) { Text("Delete") }
                }
            }

            Text("Selection mode", style = MaterialTheme.typography.labelLarge)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                PickMode.entries.forEach { mode ->
                    FilterChip(
                        selected = pool.mode == mode,
                        onClick = { onMode(mode) },
                        label = { Text("${mode.icon} ${mode.label}") }
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(onClick = onAdd, modifier = Modifier.weight(1f)) {
                    Text("＋ Add sounds")
                }
                Button(
                    onClick = onRoll,
                    enabled = pool.sounds.any { it.enabled },
                    modifier = Modifier.weight(1f)
                ) {
                    Text("🎲 ROLL & PLAY")
                }
            }

            if (pool.sounds.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 20.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No sounds yet. Feed the machine some audio.")
                }
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    pool.sounds.forEach { sound ->
                        SoundRow(
                            sound = sound,
                            playing = nowPlaying == sound.id,
                            onPreview = { onPreview(sound) },
                            onToggle = { onToggle(sound.id, it) },
                            onRemove = { onRemove(sound.id) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SoundRow(
    sound: SoundItem,
    playing: Boolean,
    onPreview: () -> Unit,
    onToggle: (Boolean) -> Unit,
    onRemove: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Checkbox(checked = sound.enabled, onCheckedChange = onToggle)
        Column(modifier = Modifier.weight(1f)) {
            Text(
                sound.name,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                fontWeight = if (playing) FontWeight.Bold else FontWeight.Normal
            )
            if (playing) Text("playing…", style = MaterialTheme.typography.labelSmall)
        }
        TextButton(onClick = onPreview) { Text(if (playing) "🔊" else "▶") }
        TextButton(onClick = onRemove) { Text("✕") }
    }
}

@Composable
private fun RoadmapCard() {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            Text("Next sockets", fontWeight = FontWeight.Bold)
            Text("v0.3  • Ringtone rotation")
            Text("v0.4  • Alarm clock + random alarm pools")
            Spacer(Modifier.height(2.dp))
            Text(
                "v0.2 deliberately keeps notification replacement conservative: it listens and plays, but does not cancel or rewrite another app's notifications.",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

@Composable
private fun NewPoolDialog(onDismiss: () -> Unit, onCreate: (String) -> Unit) {
    var name by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Create sound pool") },
        text = {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Pool name") },
                singleLine = true
            )
        },
        confirmButton = {
            TextButton(onClick = { onCreate(name) }) { Text("Create") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
private fun PoolChoiceDialog(
    title: String,
    pools: List<SoundPool>,
    selectedPoolId: String?,
    onDismiss: () -> Unit,
    onChoose: (String) -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                pools.forEach { pool ->
                    TextButton(
                        onClick = { onChoose(pool.id) },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(if (pool.id == selectedPoolId) "✓ ${pool.name}" else pool.name)
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
private fun AppRuleDialog(
    app: ObservedApp,
    pools: List<SoundPool>,
    currentRule: AppRule,
    onDismiss: () -> Unit,
    onDefault: () -> Unit,
    onExclude: () -> Unit,
    onPool: (String) -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(app.label) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Choose what this app should do:")
                TextButton(onClick = onDefault, modifier = Modifier.fillMaxWidth()) {
                    Text(if (currentRule.kind == RuleKind.DEFAULT) "✓ Use default pool" else "Use default pool")
                }
                TextButton(onClick = onExclude, modifier = Modifier.fillMaxWidth()) {
                    Text(if (currentRule.kind == RuleKind.EXCLUDED) "✓ Exclude this app" else "Exclude this app")
                }
                pools.forEach { pool ->
                    val selected = currentRule.kind == RuleKind.POOL && currentRule.poolId == pool.id
                    TextButton(
                        onClick = { onPool(pool.id) },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(if (selected) "✓ ${pool.name}" else pool.name)
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
