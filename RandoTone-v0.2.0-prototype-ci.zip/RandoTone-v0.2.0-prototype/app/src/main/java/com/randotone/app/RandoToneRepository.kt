package com.randotone.app

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.provider.OpenableColumns
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

class RandoToneRepository(private val context: Context) {
    private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun registerListener(listener: SharedPreferences.OnSharedPreferenceChangeListener) {
        prefs.registerOnSharedPreferenceChangeListener(listener)
    }

    fun unregisterListener(listener: SharedPreferences.OnSharedPreferenceChangeListener) {
        prefs.unregisterOnSharedPreferenceChangeListener(listener)
    }

    fun loadPools(): List<SoundPool> {
        val raw = prefs.getString(KEY_POOLS, null)
            ?: return listOf(SoundPool("default", "General notifications"))

        return try {
            val root = JSONArray(raw)
            val loaded = mutableListOf<SoundPool>()
            for (i in 0 until root.length()) {
                val p = root.getJSONObject(i)
                val soundArray = p.optJSONArray("sounds") ?: JSONArray()
                val sounds = mutableListOf<SoundItem>()
                for (j in 0 until soundArray.length()) {
                    val s = soundArray.getJSONObject(j)
                    sounds += SoundItem(
                        id = s.getString("id"),
                        uri = s.getString("uri"),
                        name = s.getString("name"),
                        enabled = s.optBoolean("enabled", true)
                    )
                }
                loaded += SoundPool(
                    id = p.getString("id"),
                    name = p.getString("name"),
                    mode = runCatching { PickMode.valueOf(p.getString("mode")) }
                        .getOrDefault(PickMode.SHUFFLE),
                    sounds = sounds
                )
            }
            loaded.ifEmpty { listOf(SoundPool("default", "General notifications")) }
        } catch (_: Exception) {
            listOf(SoundPool("default", "General notifications"))
        }
    }

    fun createPool(name: String) {
        val pools = loadPools()
        val clean = name.trim().ifBlank { "New pool" }
        savePools(pools + SoundPool(UUID.randomUUID().toString(), clean))
    }

    fun deletePool(poolId: String) {
        val oldPools = loadPools()
        if (oldPools.size <= 1) return

        val newPools = oldPools.filterNot { it.id == poolId }
        savePools(newPools)
        clearSelectionState(poolId)

        val fallback = newPools.first().id
        if (getDefaultPoolId(oldPools) == poolId) {
            prefs.edit().putString(KEY_DEFAULT_POOL, fallback).apply()
        }

        val rules = loadRulesObject()
        var changed = false
        val keys = rules.keys().asSequence().toList()
        keys.forEach { packageName ->
            if (rules.optString(packageName) == poolId) {
                rules.remove(packageName)
                changed = true
            }
        }
        if (changed) saveRulesObject(rules)
    }

    fun setMode(poolId: String, mode: PickMode) {
        val pools = loadPools().map { if (it.id == poolId) it.copy(mode = mode) else it }
        savePools(pools)
        clearSelectionState(poolId)
    }

    fun addSounds(poolId: String, uris: List<Uri>) {
        if (uris.isEmpty()) return

        val additions = uris.map { uri ->
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: SecurityException) {
                // Some document providers grant usable access without a persistable grant.
            }

            SoundItem(
                id = uri.toString(),
                uri = uri.toString(),
                name = displayName(uri)
            )
        }

        val pools = loadPools().map { pool ->
            if (pool.id != poolId) {
                pool
            } else {
                val existing = pool.sounds.map { it.uri }.toSet()
                pool.copy(sounds = pool.sounds + additions.filterNot { it.uri in existing })
            }
        }
        savePools(pools)
        clearSelectionState(poolId)
    }

    fun setSoundEnabled(poolId: String, soundId: String, enabled: Boolean) {
        val pools = loadPools().map { pool ->
            if (pool.id != poolId) {
                pool
            } else {
                pool.copy(
                    sounds = pool.sounds.map { sound ->
                        if (sound.id == soundId) sound.copy(enabled = enabled) else sound
                    }
                )
            }
        }
        savePools(pools)
        clearSelectionState(poolId)
    }

    fun removeSound(poolId: String, soundId: String) {
        val pools = loadPools().map { pool ->
            if (pool.id != poolId) pool
            else pool.copy(sounds = pool.sounds.filterNot { it.id == soundId })
        }
        savePools(pools)
        clearSelectionState(poolId)
    }

    @Synchronized
    fun chooseSound(poolId: String): Pair<SoundPool, SoundItem>? {
        val pool = loadPools().firstOrNull { it.id == poolId } ?: return null
        val enabled = pool.sounds.filter { it.enabled }
        if (enabled.isEmpty()) return null

        val state = loadSelectionState(poolId)
        val decision = SelectionEngine.choose(
            mode = pool.mode,
            enabledIds = enabled.map { it.id },
            state = state
        ) ?: return null

        saveSelectionState(poolId, decision.nextState)
        val sound = enabled.firstOrNull { it.id == decision.soundId } ?: return null
        return pool to sound
    }

    fun isNotificationEnabled(): Boolean = prefs.getBoolean(KEY_NOTIFICATION_ENABLED, false)

    fun setNotificationEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_NOTIFICATION_ENABLED, enabled).apply()
    }

    fun getDefaultPoolId(pools: List<SoundPool> = loadPools()): String {
        val saved = prefs.getString(KEY_DEFAULT_POOL, null)
        return pools.firstOrNull { it.id == saved }?.id ?: pools.first().id
    }

    fun setDefaultPoolId(poolId: String) {
        if (loadPools().none { it.id == poolId }) return
        prefs.edit().putString(KEY_DEFAULT_POOL, poolId).apply()
    }

    fun getRule(packageName: String): AppRule {
        val raw = loadRulesObject().optString(packageName, "")
        return when {
            raw.isBlank() -> AppRule(RuleKind.DEFAULT)
            raw == RULE_EXCLUDED -> AppRule(RuleKind.EXCLUDED)
            else -> AppRule(RuleKind.POOL, raw)
        }
    }

    fun setRuleDefault(packageName: String) {
        val rules = loadRulesObject()
        rules.remove(packageName)
        saveRulesObject(rules)
    }

    fun setRuleExcluded(packageName: String) {
        val rules = loadRulesObject()
        rules.put(packageName, RULE_EXCLUDED)
        saveRulesObject(rules)
    }

    fun setRulePool(packageName: String, poolId: String) {
        if (loadPools().none { it.id == poolId }) return
        val rules = loadRulesObject()
        rules.put(packageName, poolId)
        saveRulesObject(rules)
    }

    fun resolvePoolFor(packageName: String): SoundPool? {
        val pools = loadPools()
        val rule = getRule(packageName)
        if (rule.kind == RuleKind.EXCLUDED) return null
        val poolId = if (rule.kind == RuleKind.POOL) rule.poolId else getDefaultPoolId(pools)
        return pools.firstOrNull { it.id == poolId } ?: pools.firstOrNull()
    }

    fun loadObservedApps(): List<ObservedApp> {
        val raw = prefs.getString(KEY_OBSERVED_APPS, null) ?: return emptyList()
        return try {
            val array = JSONArray(raw)
            buildList {
                for (i in 0 until array.length()) {
                    val item = array.getJSONObject(i)
                    add(
                        ObservedApp(
                            packageName = item.getString("packageName"),
                            label = item.optString("label", item.getString("packageName")),
                            lastSeen = item.optLong("lastSeen", 0L)
                        )
                    )
                }
            }.sortedByDescending { it.lastSeen }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun recordObservedApp(packageName: String, label: String, timestamp: Long = System.currentTimeMillis()) {
        val current = loadObservedApps().associateBy { it.packageName }.toMutableMap()
        current[packageName] = ObservedApp(packageName, label.ifBlank { packageName }, timestamp)
        val trimmed = current.values.sortedByDescending { it.lastSeen }.take(MAX_OBSERVED_APPS)
        val array = JSONArray()
        trimmed.forEach { app ->
            array.put(
                JSONObject()
                    .put("packageName", app.packageName)
                    .put("label", app.label)
                    .put("lastSeen", app.lastSeen)
            )
        }
        prefs.edit().putString(KEY_OBSERVED_APPS, array.toString()).apply()
    }

    fun loadHistory(): List<HistoryEvent> {
        val raw = prefs.getString(KEY_HISTORY, null) ?: return emptyList()
        return try {
            val array = JSONArray(raw)
            buildList {
                for (i in 0 until array.length()) {
                    val item = array.getJSONObject(i)
                    add(
                        HistoryEvent(
                            id = item.getString("id"),
                            timestamp = item.getLong("timestamp"),
                            packageName = item.getString("packageName"),
                            appLabel = item.optString("appLabel", item.getString("packageName")),
                            outcome = runCatching {
                                HistoryOutcome.valueOf(item.getString("outcome"))
                            }.getOrDefault(HistoryOutcome.PLAYBACK_ERROR),
                            poolName = item.optString("poolName").takeIf { it.isNotBlank() },
                            soundName = item.optString("soundName").takeIf { it.isNotBlank() }
                        )
                    )
                }
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun addHistory(
        packageName: String,
        appLabel: String,
        outcome: HistoryOutcome,
        poolName: String? = null,
        soundName: String? = null,
        timestamp: Long = System.currentTimeMillis()
    ) {
        val updated = listOf(
            HistoryEvent(
                id = UUID.randomUUID().toString(),
                timestamp = timestamp,
                packageName = packageName,
                appLabel = appLabel,
                outcome = outcome,
                poolName = poolName,
                soundName = soundName
            )
        ) + loadHistory()

        val array = JSONArray()
        updated.take(MAX_HISTORY).forEach { event ->
            array.put(
                JSONObject()
                    .put("id", event.id)
                    .put("timestamp", event.timestamp)
                    .put("packageName", event.packageName)
                    .put("appLabel", event.appLabel)
                    .put("outcome", event.outcome.name)
                    .put("poolName", event.poolName ?: "")
                    .put("soundName", event.soundName ?: "")
            )
        }
        prefs.edit().putString(KEY_HISTORY, array.toString()).apply()
    }

    fun clearHistory() {
        prefs.edit().remove(KEY_HISTORY).apply()
    }

    private fun savePools(pools: List<SoundPool>) {
        val root = JSONArray()
        pools.forEach { pool ->
            val sounds = JSONArray()
            pool.sounds.forEach { sound ->
                sounds.put(
                    JSONObject()
                        .put("id", sound.id)
                        .put("uri", sound.uri)
                        .put("name", sound.name)
                        .put("enabled", sound.enabled)
                )
            }
            root.put(
                JSONObject()
                    .put("id", pool.id)
                    .put("name", pool.name)
                    .put("mode", pool.mode.name)
                    .put("sounds", sounds)
            )
        }
        prefs.edit().putString(KEY_POOLS, root.toString()).apply()
    }

    private fun displayName(uri: Uri): String {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val column = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (column >= 0) return cursor.getString(column)
                }
            }
        return uri.lastPathSegment ?: "Sound"
    }

    private fun loadSelectionState(poolId: String): SelectionState {
        val raw = prefs.getString(selectionKey(poolId), null) ?: return SelectionState()
        return try {
            val obj = JSONObject(raw)
            val bagJson = obj.optJSONArray("bag") ?: JSONArray()
            val bag = buildList {
                for (i in 0 until bagJson.length()) add(bagJson.getString(i))
            }
            SelectionState(
                lastId = obj.optString("lastId").takeIf { it.isNotBlank() },
                bag = bag
            )
        } catch (_: Exception) {
            SelectionState()
        }
    }

    private fun saveSelectionState(poolId: String, state: SelectionState) {
        val bag = JSONArray()
        state.bag.forEach { bag.put(it) }
        val obj = JSONObject()
            .put("lastId", state.lastId ?: "")
            .put("bag", bag)
        prefs.edit().putString(selectionKey(poolId), obj.toString()).apply()
    }

    private fun clearSelectionState(poolId: String) {
        prefs.edit().remove(selectionKey(poolId)).apply()
    }

    private fun loadRulesObject(): JSONObject {
        val raw = prefs.getString(KEY_RULES, null) ?: return JSONObject()
        return runCatching { JSONObject(raw) }.getOrDefault(JSONObject())
    }

    private fun saveRulesObject(rules: JSONObject) {
        prefs.edit().putString(KEY_RULES, rules.toString()).apply()
    }

    private fun selectionKey(poolId: String) = "selector_$poolId"

    companion object {
        const val PREFS_NAME = "randotone_v01"
        const val KEY_POOLS = "pools"
        const val KEY_NOTIFICATION_ENABLED = "notification_enabled"
        const val KEY_DEFAULT_POOL = "notification_default_pool"
        const val KEY_RULES = "notification_rules"
        const val KEY_OBSERVED_APPS = "observed_apps"
        const val KEY_HISTORY = "notification_history"

        private const val RULE_EXCLUDED = "__EXCLUDED__"
        private const val MAX_OBSERVED_APPS = 80
        private const val MAX_HISTORY = 50
    }
}
