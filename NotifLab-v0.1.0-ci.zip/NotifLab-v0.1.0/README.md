# NotifLab v0.1.0

A small Android notification test harness designed to exercise notification-listener apps such as RandoTone.

## Local tests
- Normal notification
- Burst of 5 notifications
- Repeated update of the same notification ID
- Same-ID update with `setOnlyAlertOnce(true)`
- 3 grouped child notifications plus a group summary
- Ongoing notification
- CALL category notification
- ALARM category notification
- Cancel all

The test notification channel is intentionally silent, so source-app audio does not interfere with RandoTone tests.

## Wireless PC control
NotifLab starts a tiny HTTP server on TCP port `8765` while the app is open. The app shows its local IPv4 address, for example:

`http://192.168.1.123:8765/`

Open that address from a PC on the same local network. No PC software or cloud service is required.

This is a LAN-only convenience test server and has no authentication. Turn it off by closing NotifLab or leaving the test network when you do not need it.
